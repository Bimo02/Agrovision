import os
import sys
# for vision model and images visulization
import io
import requests
from PIL import Image
# for chat with docs
import tempfile
from langchain_community.document_loaders import PyPDFLoader
# from langchain_community.vectorstores import Chroma
from langchain_community.vectorstores.chroma import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains.question_answering import load_qa_chain
from langchain_core.prompts import PromptTemplate
# for identifythe url content type
from urllib.parse import urlparse
# for speech recognition
from SpeechRecognition import recognize_speech, process_user_voice, voice, speek
# for chating with our database
from gemini_data_chat import retrieval_qa_pipline
# for load gemini models api keys
import google.generativeai as genai
from dotenv import load_dotenv
import firebase_admin
from firebase_admin import credentials, db
import requests
load_dotenv()

GOOGLE_API_KEY = genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Set up the model
generation_config = {
  "temperature": 1,
  "top_p": 1,
  "top_k": 64,
  "max_output_tokens": 8192,
  "response_mime_type": "text/plain",
}
safety_settings = [
  {
    "category": "HARM_CATEGORY_HARASSMENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_HATE_SPEECH",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
]
memory = [] # global conversation_memory
MAX_MEMORY = 5
def gemini_chat_model(query, img=None):
    global memory
    if len(memory) > MAX_MEMORY:
     memory.pop(0)  # Remove the oldest conversation entry

    memory.append(f"User: {query}")  # Store user query

    historical_prompt = """
    *"You are Khedr, an intelligent AI assistant specializing in smart agriculture, crop health, and sustainable farming. Your role is to provide expert guidance to farmers, agricultural researchers, and enthusiasts by leveraging AI-driven disease detection, real-time sensor data, and best farming practices.

You communicate fluently in both Arabic and English and always respond in the same language as the user’s query. explaining complex agricultural concepts in a simple, friendly, and practical manner. Your expertise includes:

✅ Plant Disease Detection – Analyzing leaf images using AI models to diagnose diseases and recommend treatments.
✅ Soil Analysis & Optimization – Interpreting sensor data (NPK, moisture, pH, temperature) to provide insights on fertilization and irrigation.
✅ Precision Farming & IoT Integration – Helping users understand how smart sensors and automation can improve crop yield.
✅ Weather & Climate Insights – Offering guidance on farming practices based on weather forecasts and climate conditions.
✅ Sustainable Agriculture – Promoting eco-friendly farming techniques, resource efficiency, and long-term soil health.

💡 Response Guidelines:
If the user asks something outside of agriculture, politely redirect them back to farming-related topics.

If a query is agriculture-related but outside your predefined knowledge, perform an online search to find relevant, up-to-date information before responding.

Maintain a friendly, engaging, and practical tone, ensuring responses are useful for real-world farming decisions.

No Repetitive Introductions → Only introduce yourself in the first message. Avoid saying "Hello" in every response.

You can provide voice-based assistance when needed for accessibility and ease of use.

If an image is provided:

Analyze it only if it relates to crops, soil, or farming.

If the image is not related to agriculture, inform the user that you cannot analyze it.

Your mission is to empower farmers with data-driven insights, helping them make informed decisions for healthier crops and better yields."*"""
    #memory.append(f"User: {query}")
    full_query = historical_prompt + "\n" + "\n".join(memory)
    gemini_model = genai.GenerativeModel(model_name="gemini-2.0-flash",
                                             generation_config=generation_config,
                                             safety_settings=safety_settings)
    # Determine which model to use based on the presence of an image
    if img:
        response = gemini_model.generate_content([full_query, img])
    else:
        response = gemini_model.generate_content(full_query)

    memory.append(f"answer: {response.text}")
    return response.text

def identify_url_content(url):
    
    try:
        response = requests.head(url, allow_redirects=True)
        content_type = response.headers.get('content-type')

        if 'image' in content_type:
            return "image"
        elif 'pdf' in content_type:
            return "pdf"
        else:
            # Analyze file extension as a fallback
            parsed_url = urlparse(url)
            file_extension = parsed_url.path.split('.')[-1].lower()
            if file_extension == 'pdf':
                return "pdf"
            else:
                return "unknown"  # Return "unknown" for other types
    except Exception as e:
        print(f"Error processing URL: {e}")
        return "unknown"
    
def handle_answer(query, answer):
    memory.append(f"User: {query}")
    memory.append(f"Answer: {answer}")
    print(f"Question: {query}")
    print(f"Answer: {answer}")
    voice_response = input("\nDo you want to hear the response? (yes or no): ").lower()
    if voice_response in ['yes', 'y']:
        voice(answer)   

def text_conversation():
    while True:
        query = input("Enter a query: ")

        if query.lower() in ['quit', 'q', 'exit']:
            return

        if query:
            if query.startswith('http'):
                content_type = identify_url_content(query)
                if content_type == 'image':
                    image_conversation(query)
                elif content_type == 'pdf':
                    pdf_conversation(query)
            else:
                qa = retrieval_qa_pipline()
                res = qa.invoke({"query": query})
                answer = res["result"]
                #handle_answer(query, answer)
                if answer.lower() == 'The answer is not available in my current knowledge base.': 
                    convo = gemini_chat_model(query)
                    handle_answer(query, convo)
                else:
                    handle_answer(query, answer)
                    

def voice_conversation():
    while True:
        query = process_user_voice()

        if query.lower() in ['quit', 'q', 'exit']:
            return

        if query:
            qa = retrieval_qa_pipline()
            res = qa.invoke({"query": query})
            answer = res["result"]

            if answer.lower() != 'The answer is not available in my current knowledge base.':
                handle_answer(query, answer)
            else:
                # Use the conversational model if no answer from the database
                convo = gemini_chat_model(query)
                handle_answer(query, convo)    

def image_conversation(image_source):
    
    if image_source.startswith('http'):
        response = requests.get(image_source)
        if response.status_code == 200:
            img = Image.open(io.BytesIO(response.content))
        else:
            print(f"Error downloading image: {response.status_code}")
            return
    else:
        if not os.path.isfile(image_source):
            raise SystemExit("Invalid image path")
        img = Image.open(image_source)

    while True:
        conv_img_type = input("\nPlease enter 't' for text conversation about this image or enter 'v' for voice conversation about this image: ").lower()
        if conv_img_type == 't':
            question = input("\nEnter your question about this image: ")
            if question.lower() in ['quit', 'q', 'exit']:
                return
            else:
                convo = gemini_chat_model(question, img)
                handle_answer(question, convo)
                  
        elif conv_img_type == 'v':
            question = recognize_speech()
            # question = process_user_voice()  
            if question.lower() in ['quit', 'q', 'exit']:
                return
            else:
                convo = gemini_chat_model(question, img)
                handle_answer(question, convo)
                      

def pdf_conversation(file_source):
    # Load PDF content
    if os.path.isfile(file_source):
        pdf_loader = PyPDFLoader(file_source)
        pages = pdf_loader.load_and_split()
    else:
        response = requests.get(file_source, stream=True)
        if response.status_code == 200:
            with tempfile.NamedTemporaryFile(delete=False) as temp_pdf:
                temp_pdf.write(response.content)
                pdf_loader = PyPDFLoader(temp_pdf.name)
                pages = pdf_loader.load_and_split()
        else:
            raise SystemExit(f"Error downloading PDF: {response.status_code}")

    # Prepare text for embedding and retrieval
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    context = "\n\n".join(str(p.page_content) for p in pages)
    texts = text_splitter.split_text(context)

    # Create embeddings and vector index
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=GOOGLE_API_KEY)
    vector_index = Chroma.from_texts(texts, embeddings).as_retriever(search_kwargs={"k": 5})

    # Set up model and chain for question answering
    model = ChatGoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=GOOGLE_API_KEY, temperature=1)
    qa_chain = RetrievalQA.from_chain_type(
        model, retriever=vector_index, return_source_documents=False
    )

    # Define prompt template
    prompt_template = """
    You are Khedr, an intelligent and knowledgeable AI assistant specializing in smart agriculture. You provide expert advice on farming, crop health, soil conditions, and sustainable agricultural practices. Your knowledge is backed by real-time sensor data from IoT devices and AI-driven disease detection models.

You assist farmers and agricultural researchers by answering questions in both Arabic and English, explaining complex concepts in a simple and friendly manner. Your expertise includes:
    If the query is not about agricultre or the image is not related to farming, please state that you cannot analyze it.
    
    If the query related to Agriculture and not in the context provided please search online and get answers for the user.
    
Plant disease detection: Using AI models trained on leaf images to diagnose and suggest treatments.
Soil analysis & recommendations: Interpreting sensor data (NPK, moisture, pH, temperature) to guide optimal fertilization and irrigation.
Precision farming & IoT integration: Helping users understand how smart sensors and automation can enhance yield.
Weather & climate insights: Advising on best farming practices based on weather conditions.
Sustainable agriculture: Promoting eco-friendly farming techniques and resource efficiency.
Your responses should be engaging, friendly, and practical, always aiming to support farmers in making data-driven decisions. You can also provide voice-based assistance when needed. If the user asks something outside your scope, guide them back to agriculture-related topics."*
    If the query is not about agricultre or the image is not related to farming, please state that you cannot analyze it.
    if the query is not in the provided context and related to agricultue or crop disease please search online for an answer before responding!!
    Context:
    {context}
    Question:
    {question}
    Answer:
    """
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    full_prompt = prompt + "\n" + "\n".join(memory)

    # Create Stuff chain
    stuff_chain = load_qa_chain(model, chain_type="stuff", prompt=full_prompt)

    while True:
        # Get user input type
        conv_pdf_type = input("\nPlease enter 't' for text conversation about this pdf or 'v' for voice conversation about this pdf: ")

        if conv_pdf_type == 't':
            question = input("\nEnter your question about this PDF: ")
        elif conv_pdf_type == 'v':
            print("\nEnter your question about this PDF: ")
            question = recognize_speech()
            # question = process_user_voice()
        else:
            print("Invalid input. Please enter 't' or 'v'.")
            continue

        # Exit if requested
        if question.lower() in ['quit', 'q', 'exit']:
            break
        result = stuff_chain.invoke({"input_documents": pages, "question": question}, return_only_outputs=True)
        handle_answer(question, result['output_text'])

def main():
    while True:
        conv_type = input("\nPlease enter 't' for text, 'v' for voice, 'i' for images, or 'p' for PDF conversation, or 'exit' to end the program: ").lower()

        if conv_type == 't':
            text_conversation()
        elif conv_type == 'v':
            voice_conversation()
        elif conv_type == 'i':
           image_path = input("\nplease enter yout image path: ")
           image_conversation(image_path)
        elif conv_type == 'p':
            pdf_path = input("\nEnter the path to your PDF file: ")
            pdf_conversation(pdf_path)
        elif conv_type.lower() in ['quit', 'q', 'exit']:
            sys.exit()
        else:
            print("Invalid input. Please enter 't', 'v', 'i', or 'p'.")

if __name__ == "__main__":
    main()