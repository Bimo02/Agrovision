<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception;

class OutOfRangeException extends \OutOfRangeException implements FirebaseException
{
}
